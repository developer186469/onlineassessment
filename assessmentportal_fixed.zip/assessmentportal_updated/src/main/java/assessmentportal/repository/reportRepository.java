package assessmentportal.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import assessmentportal.model.ExamReport;

public interface reportRepository extends JpaRepository<ExamReport, Long>{

	List<ExamReport> findAllByOrderByTestDate();
}
