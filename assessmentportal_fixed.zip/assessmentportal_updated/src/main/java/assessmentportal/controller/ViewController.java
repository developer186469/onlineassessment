package assessmentportal.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import assessmentportal.model.Answers;
import assessmentportal.model.ExamReport;

import assessmentportal.service.ReportService;

@Controller
public class ViewController {

	@Autowired
	private ReportService reportService;
	
	@Autowired
	private Answers answers;

	    @GetMapping("/user/springAssessment")
	    public String exam1(Model model) {
	    	ExamReport examreport = new ExamReport();
	    	model.addAttribute("examreport", examreport);
	        return "/springAssessment";
	    }

	    
	    @GetMapping("/user/hibernateAssessment")
	    public String exam2(Model model) {
	    	ExamReport examreport = new ExamReport();
	    	model.addAttribute("examreport", examreport);
	        return "/hibernateAssessment";
	    }

	    @GetMapping("/viewreports")
	    public String viewCandidate(Model model)    {
	    	
	    	List < ExamReport > reports = new ArrayList < ExamReport> ();
	    
			reports = reportService.findAllByOrderByTestDate();
	    		    	
	    	model.addAttribute("reports",reports);
	    	
	    	return "/viewreports";
	    }


		@PostMapping("/user/evaluate")
		public String submitForm(@ModelAttribute("examreport") ExamReport examreport, Authentication auth) {
			
			examreport.setCandidateMailID(auth.getName());
			examreport.setTestDate(LocalDateTime.now());
			
			List<String> rightAnswers;
					
			if(examreport.getTestName().equals("Spring")) {
				rightAnswers = answers.getRightanswersSpring();
				 
				   List<String> userAnswers=new ArrayList<String>();
				   userAnswers.add(examreport.getQuestion1());
				   userAnswers.add(examreport.getQuestion2());
				   userAnswers.add(examreport.getQuestion3());
				   userAnswers.add(examreport.getQuestion4());
				   userAnswers.add(examreport.getQuestion5());
				   
				   userAnswers.retainAll(rightAnswers);
				   
				   examreport.setScore((userAnswers.size())*10);
				   
				   
				   if (examreport.getScore()>=30)
				   {
			 
			   examreport.setResult("Passed");
			 
			   reportService.saveReport(examreport);
		    return "success";
		} 				  
			}
			else if(examreport.getTestName().equals("Hibernate")) {
				
			rightAnswers=answers.getRightanswersHibernate();
				   
				   List<String> userAnswers=new ArrayList<String>();
				   userAnswers.add(examreport.getQuestion1());
				   userAnswers.add(examreport.getQuestion2());
				   userAnswers.add(examreport.getQuestion3());
				   userAnswers.add(examreport.getQuestion4());
				   userAnswers.add(examreport.getQuestion5());
				   
				   userAnswers.retainAll(rightAnswers);
				   
				   examreport.setScore((userAnswers.size())*10);
				  				   
				   if (examreport.getScore()>=30)
						   {
					 
					   examreport.setResult("Passed");
					   reportService.saveReport(examreport);
					 					   
				    return "success";
				} 
				 
			}
		
				examreport.setResult("Failed");
				reportService.saveReport(examreport);
				return "failure";
			
	
		}
	    
		}
