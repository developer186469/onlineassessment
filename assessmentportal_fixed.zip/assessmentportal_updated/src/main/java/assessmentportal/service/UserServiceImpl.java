package assessmentportal.service;


import assessmentportal.model.Role;
import assessmentportal.model.User;
import assessmentportal.repository.RoleRepository;
import assessmentportal.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private RoleRepository roleRepository;
    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    @Override
    public void save(User user) {
        user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
        Set<Role> roleSet = new HashSet<>();
        roleSet.add(roleRepository.findByName("USER_ROLE"));
        user.setRoles(roleSet);
        userRepository.save(user);
    }

    @Override
    public List<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

	@Override
	public List<User> findAllByOrderByFirstname() {
		// TODO Auto-generated method stub
		
		return userRepository.findAllByOrderByFirstname();
	}
}
