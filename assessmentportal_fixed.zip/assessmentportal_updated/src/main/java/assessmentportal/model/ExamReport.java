package assessmentportal.model;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;


@Entity
@Table(name="exam")
public class ExamReport {
	
	
	private Long id;
	
	@DateTimeFormat(pattern = "dd-MM-yyyy HH:mm:ss")
	private LocalDateTime testDate;
	
	private String testName;
	private String candidateMailID;
	private int score;
	
	private String result;
	
	private String Question1,Question2, Question3,Question4, Question5;
		
	
	 	@Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    public Long getId() {
	        return id;
	    }

	    public void setId(Long id) {
	        this.id = id;
	    }
	
	public LocalDateTime getTestDate() {
		return testDate;
	}
	public void setTestDate(LocalDateTime testDate) {
		this.testDate = testDate;
	}
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public String getCandidateMailID() {
		return candidateMailID;
	}
	public void setCandidateMailID(String candidateMailID) {
		this.candidateMailID = candidateMailID;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}

	public String getQuestion1() {
		return Question1;
	}

	public void setQuestion1(String question1) {
		Question1 = question1;
	}

	public String getQuestion2() {
		return Question2;
	}

	public void setQuestion2(String question2) {
		Question2 = question2;
	}

	public String getQuestion3() {
		return Question3;
	}

	public void setQuestion3(String question3) {
		Question3 = question3;
	}

	public String getQuestion4() {
		return Question4;
	}

	public void setQuestion4(String question4) {
		Question4 = question4;
	}

	public String getQuestion5() {
		return Question5;
	}

	public void setQuestion5(String question5) {
		Question5 = question5;
	}
}
