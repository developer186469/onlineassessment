package assessmentportal.model;


import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class Answers {


	private final List<String> rightanswersSpring= Arrays.asList(new String[]{"J2EE App Development Framework","Inversion Of Control","Aspect Oriented Programming","Application Context","Dispatcher Servlet"});

	private final List<String> rightanswersHibernate= Arrays.asList(new String[]{"Object Relational Mapping","uni-directional and bi-directional","configuration file","Hibernate Query Language","isolation levels"});

	public List<String> getRightanswersSpring() {
		return rightanswersSpring;
	}

	public List<String> getRightanswersHibernate() {
		return rightanswersHibernate;
	}
	


}
