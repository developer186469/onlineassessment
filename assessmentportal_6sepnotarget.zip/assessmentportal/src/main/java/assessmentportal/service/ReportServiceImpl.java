package assessmentportal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import assessmentportal.model.ExamReport;
import assessmentportal.repository.reportRepository;

@Service
public class ReportServiceImpl implements ReportService{

	@Autowired
	private reportRepository reportRepository;
	
	@Override
	public void saveReport(ExamReport report) {
		// TODO Auto-generated method stub
		reportRepository.save(report);
	}

	@Override
	public List<ExamReport> findAllByOrderByTestDate() {
		// TODO Auto-generated method stub
		return reportRepository.findAllByOrderByTestDate();
	}

	

}
