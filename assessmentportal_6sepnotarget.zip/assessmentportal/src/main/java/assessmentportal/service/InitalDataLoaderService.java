package assessmentportal.service;


import assessmentportal.model.Role;
import assessmentportal.model.User;
import assessmentportal.repository.RoleRepository;
import assessmentportal.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.HashSet;


@Component
public class InitalDataLoaderService implements ApplicationListener<ContextRefreshedEvent> {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {

        System.out.println("Creating role ADMIN");
        Role adminRole = createUserRoles("ADMIN_ROLE");

        System.out.println("Creating role USER");
        createUserRoles("USER_ROLE");

        System.out.println("Creating user Admin");

        User user = new User();
        user.setFirstname("Roger");
        user.setLastname("Kutcher");
        user.setPassword(bCryptPasswordEncoder.encode("wipro@123"));
        user.setUsername("roger@gmail.com");
        user.setRoles(new HashSet<>(Arrays.asList(adminRole)));
        userRepository.save(user);

        User user1 = new User();
        user1.setFirstname("Steve");
        user1.setLastname("Martin");
        user1.setPassword(bCryptPasswordEncoder.encode("wipro@123"));
        user1.setUsername("steve@gmail.com");
        user1.setRoles(new HashSet<>(Arrays.asList(adminRole)));
        userRepository.save(user1);

    }

    @Transactional
    Role createUserRoles(String name){
        Role role = new Role(name);
        roleRepository.save(role);
        return role;

    }

}
