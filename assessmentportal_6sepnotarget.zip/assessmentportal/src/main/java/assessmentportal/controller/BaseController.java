package assessmentportal.controller;


import assessmentportal.model.User;
import assessmentportal.service.UserService;
import assessmentportal.validator.UserValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

@Controller
public class BaseController {

    @Autowired
    private UserService userService;

    @Autowired
    private UserValidator userValidator;

    @GetMapping("/")
    public String home() {
        return "/login";
    }

    @GetMapping("/login")
    public String login() {
        return "/login";
    }

    @GetMapping("/registration")
    public String register(Model model) {
        model.addAttribute("user", new User());
        System.out.println("inside registration");
        return "/registration";
    }

    @PostMapping(value = "/registration")
    public String registration(@ModelAttribute("user") User user, BindingResult result,  Model model) {
        System.out.println("Inside registration put");
        userValidator.validate(user, result);

        if (result.hasErrors()) {
            System.out.println("Registration has errors");
            return "registration";
        }

        userService.save(user);
        System.out.println("Username registered : " + user.getUsername());
        model.addAttribute("userdetails",user);
        return "/welcome";
    }

    @GetMapping("/viewcandidates")
    public String viewCandidate(Model model)    {
    	
    	
     	List < User > userlist = new ArrayList < User> ();
    	userlist = userService.findAllByOrderByFirstname();
    	
    	model.addAttribute("users",userlist);
    	
    	return "/viewcandidates";
    }
    
    @GetMapping("/admin")
    public String admin() {
        return "/admin";
    }

    @GetMapping("/user")
    public String user() {
        return "/user";
    }

    @GetMapping("/welcome")
    public String userWelcome(@ModelAttribute User user) {
        return "/welcome";
    }

    @GetMapping("/logout")
    public String logout() {
        return "/login";
    }

    @GetMapping("/403")
    public String error403() {
        return "/403";
    }


}
