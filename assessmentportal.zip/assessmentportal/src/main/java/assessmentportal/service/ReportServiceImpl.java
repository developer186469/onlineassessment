package assessmentportal.service;

import java.util.List;

import assessmentportal.model.ExamReport;

public class ReportServiceImpl implements ReportService{

	private reportRepository reportRepository;
	
	@Override
	public void saveReport(ExamReport report) {
		// TODO Auto-generated method stub
		reportRepository.save(report);
	}

	@Override
	public List<ExamReport> getAllExamReports() {
		// TODO Auto-generated method stub
		return null;
	}

	

}
