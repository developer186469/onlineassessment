package assessmentportal.service;

import java.util.List;

import assessmentportal.model.ExamReport;

public interface ReportService {

	void saveReport(ExamReport report);
	public abstract List<ExamReport> getAllExamReports();
	
}
