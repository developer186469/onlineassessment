package assessmentportal.service;

import org.springframework.data.jpa.repository.JpaRepository;

import assessmentportal.model.ExamReport;

public interface reportRepository extends JpaRepository<ExamReport, Long>{

}
