package assessmentportal.model;

import javax.persistence.*;

import java.util.ArrayList;

import java.time.LocalDateTime;
import java.util.List;


@Entity
@Table(name="exam")
public class ExamReport {
	
	private Long id;
	private LocalDateTime testDate;
	private String testName;
	private String candidateMailID;
	private int score;
	final int totalMarks=50;
	private String result;
	private List<String> answers= new ArrayList<String>();
	
	 	@Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    public Long getId() {
	        return id;
	    }

	    public void setId(Long id) {
	        this.id = id;
	    }
	
	public LocalDateTime getTestDate() {
		return testDate;
	}
	public void setTestDate(LocalDateTime testDate) {
		this.testDate = testDate;
	}
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public String getCandidateMailID() {
		return candidateMailID;
	}
	public void setCandidateMailID(String candidateMailID) {
		this.candidateMailID = candidateMailID;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public ArrayList<String> getAnswers() {
		return (ArrayList<String>) answers;
	}
	public void setAnswers(ArrayList<String> answers) {
		this.answers = answers;
	}
	
	
}
