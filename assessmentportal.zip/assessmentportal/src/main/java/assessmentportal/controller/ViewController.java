package assessmentportal.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import assessmentportal.model.ExamReport;

@Controller
public class ViewController {

	 @GetMapping("/")
	    public String home() {
	        return "/index";
	    }

	    @GetMapping("/springAssessment")
	    public String exam1(Model model) {
	    	ExamReport examreport = new ExamReport();
	    	model.addAttribute("examreport", examreport);
	        return "/springAssessment";
	    }

	    
	    @GetMapping("/hibernateAssessment")
	    public String exam2(Model model) {
	    	ExamReport examreport = new ExamReport();
	    	model.addAttribute("examreport", examreport);
	        return "/hibernateAssessment";
	    }


		@PostMapping("/evaluate")
		public String submitForm(@ModelAttribute("examreport") ExamReport examreport) {
			
			if(examreport.getTestName().equals("Spring")) {
				   List<String> rightAnswers=new ArrayList<String>();
				   rightAnswers.add("J2EE App Development Framework");
				   rightAnswers.add("Inversion Of Control");
				   rightAnswers.add("Aspect Oriented Programming");
				   rightAnswers.add("Application Context");
				   rightAnswers.add("Dispatcher Servlet");
				   
				 
				   
				   examreport.getAnswers().retainAll(rightAnswers);
				   
				   examreport.setScore((examreport.getAnswers().size())*10);
				   examreport.setTestDate(LocalDateTime.now());
				   
				   if (examreport.getScore()>=30)
						   {
					 
					   examreport.setResult("Passed");
				    return "success";
				}
			}
			else if(examreport.getTestName().equals("Hibernate")) {
				  System.out.println(examreport.getCandidateMailID());
				  return "failure";
			}
		
		   examreport.setResult("Failed");
		   return "failure";
		}
	    
		}
